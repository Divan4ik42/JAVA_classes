package edu.Divan.model;

public class Client {
    
    
}
