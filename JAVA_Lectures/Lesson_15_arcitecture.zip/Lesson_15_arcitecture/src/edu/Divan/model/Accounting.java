package edu.Divan.model;

public class Accounting {

    private String id;
    private Chamber chamber;
    private int sum;
    
}
