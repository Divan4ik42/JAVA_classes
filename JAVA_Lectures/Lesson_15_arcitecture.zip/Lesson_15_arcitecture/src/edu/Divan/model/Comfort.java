package edu.Divan.model;

public enum Comfort {
    HOSTEL, LUX, SEMILUX, STANDART, PRESIDENTLUX, ALLINCLUDED;
}
