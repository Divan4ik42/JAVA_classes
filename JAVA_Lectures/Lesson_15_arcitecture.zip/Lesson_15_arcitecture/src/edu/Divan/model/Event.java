package edu.Divan.model;

public enum Event {
    
    CHECKIN, CHECKOUT, PROLONG, CHANGE;
}
